//
//  MyData.swift
//  Maz-UICollection-Picker-V1
//
//  Created by Shaik abdul mazeed on 02/03/21.
//

import Foundation
import UIKit
struct MyData {
    var myImage = UIImage()
    var firstName:String = ""
    var LastName:String = ""
    var DOB:String = ""
    var profession:String = ""
}
