//
//  MazCVCell.swift
//  Maz-UICollection-Picker-V1
//
//  Created by Shaik abdul mazeed on 02/03/21.
//

import UIKit

class MazCVCell: UICollectionViewCell {

    @IBOutlet weak var mazCV: UIImageView!
    
    @IBOutlet weak var profession: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
